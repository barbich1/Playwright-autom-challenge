import { Page, Locator, expect } from '@playwright/test';

export class CartPage {
readonly page: Page;
readonly cartItems: Locator;
readonly checkoutButton: Locator;

constructor(page: Page) {
    this.page = page;
    this.cartItems = page.locator('.cart_item');
    this.checkoutButton = page.locator('[data-test="checkout"]');
}

async assertCartHasAtLeastItems(n: number) {
    const count = await this.cartItems.count();
    expect(count).toBeGreaterThanOrEqual(n);
}

async clickCheckout() {
    await this.checkoutButton.click();
}
}
