import { Page, Locator, expect } from '@playwright/test';

export class InventoryPage {
readonly page: Page;
readonly sortSelect: Locator;
readonly title: Locator;
readonly addToCartButtons: Locator;
readonly cartIcon: Locator;

constructor(page: Page) {
    this.page = page;
    // acá uso la CLASE en lugar del data-test
    this.sortSelect = page.locator('.product_sort_container');
    this.title = page.locator('.title');
    this.addToCartButtons = page.locator('button[data-test^="add-to-cart"]');
    this.cartIcon = page.locator('#shopping_cart_container');
}

async assertOnInventoryPage() {
await expect(this.page.locator('.title')).toHaveText('Products');
}


async sortByPriceLowToHigh() {
    await this.sortSelect.selectOption('lohi'); // Price (low to high)
}

async addFirstNProductsToCart(n: number) {
    const total = await this.addToCartButtons.count();
    const limit = Math.min(n, total);

    for (let i = 0; i < limit; i++) {
    await this.addToCartButtons.nth(i).click();
    }
}

async goToCart() {
    await this.cartIcon.click();
}
}
