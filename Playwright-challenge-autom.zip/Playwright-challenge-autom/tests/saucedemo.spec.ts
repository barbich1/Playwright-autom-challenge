import { test } from '@playwright/test';
import { LoginPage } from '../pages/login.page';
import { InventoryPage } from '../pages/inventory.page';
import { CartPage } from '../pages/cart.page';
import { CheckoutPage } from '../pages/checkout.page';

test('Challenge SauceDemo completo', async ({ page }) => {
const login = new LoginPage(page);
const inventory = new InventoryPage(page);
const cart = new CartPage(page);
const checkout = new CheckoutPage(page);

  // 1) Login
await login.goto();
await login.login('standard_user', 'secret_sauce');
await inventory.assertOnInventoryPage();

  // 2) Filtrar por precio de menor a mayor
await inventory.sortByPriceLowToHigh();

  // 3) Agregar 2 productos
await inventory.addFirstNProductsToCart(2);
await inventory.goToCart();
await cart.assertCartHasAtLeastItems(2);

  // 4) Checkout + Validación
await cart.clickCheckout();
await checkout.fillCheckoutForm('Barbara', 'Tester', '1234');
await checkout.finishOrder();
await checkout.assertOrderCompleted();
});
